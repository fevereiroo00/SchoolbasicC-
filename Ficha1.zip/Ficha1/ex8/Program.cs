﻿using System;

namespace ex8
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1, n2, n3, n4; //declarar variaveis em tipo inteiro

            Console.WriteLine("Insere um valor"); //pedir ao utilizador o 1 valor
            n1 = int.Parse(Console.ReadLine()); //armazenar o primeiro valor em n1

            Console.WriteLine("Insere o segundo valor"); //pedir ao utilizador o 2 valor
            n2 = int.Parse(Console.ReadLine()); //armazenar o segundo valor em n2

            Console.WriteLine("Insere o terceiro valor"); //pedir ao utilizador o 3 valor
            n3 = int.Parse(Console.ReadLine()); //armazenar o terceiro valor em n3

            Console.WriteLine("Insere o quarto valor"); //pedir ao utilizador o 4 valor
            n4 = int.Parse(Console.ReadLine()); //armazenar o quarto valor em n4

            if (n1 == n2 && n2 == n3 && n3 == n4) //se os valores n1,n2,n3,n4 são iguais 
            {
                Console.WriteLine("Os valores são iguais");//Imprimir o resultado
            }
            else if (n1 < n2 && n1 < n3 && n1 < n4) //se o n1 é o menor 
            {
                Console.WriteLine("O primeiro numero é o menor");//Imprimir o resultado
            }
            else if (n2 < n1 && n2 < n3 && n2 < n4) //se o n2 é o menor 
            {
                Console.WriteLine("O segundo numero é o menor"); //Imprimir o resultado
            }
            else if (n3 < n1 && n3 < n2 && n3 < n4) //se o n3 é o menor
            {
                Console.WriteLine("O terceiro numero é o menor"); //Imprimir o resultado
            }
            else
            {
                Console.WriteLine("O quarto numero é o menor");//Imprimir o resultado
            }
               
        }
    }
}
