﻿using System;

namespace ex3
{
    class Program
    {
        static void Main(string[] args)
        {
            int var1, var2, resultado; //declarar variaveis em tipo inteiro

            Console.WriteLine("Insira o primeiro valor"); //pedir ao utilizador o 1 valor
            var1 = int.Parse(Console.ReadLine()); //armazenar o primeiro valor em var1
            Console.WriteLine("Insira o segundo valor"); //pedir ao utilizador o 2 valor
            var2 = int.Parse(Console.ReadLine()); //armazenar o segundo valor em var2
            resultado = var1 - var2; //algoritmo diferença entre dois numeros
            Console.WriteLine("A diferença de " + var1 + " - " + var2 + " = " + resultado); //apresnetar o resultado 
        }
    }
}
