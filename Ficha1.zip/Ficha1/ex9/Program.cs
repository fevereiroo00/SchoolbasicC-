﻿using System;

namespace ex9
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1; //declarar variaveis em tipo inteiro

            Console.WriteLine("Insere um valor"); //pedir ao utilizador o 1 valor
            n1 = int.Parse(Console.ReadLine()); //armazenar o primeiro valor em n1

            if ((n1 % 2) == 0) //se o valor é par
            {
                Console.WriteLine("O valor é par"); //imprimir resultado
            }
            else //se o valor for impar
            {
                Console.WriteLine("O valor é impar"); //imprimir resultado
            }
        }
    }
}
