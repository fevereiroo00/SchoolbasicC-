﻿using System;

namespace ex5
{
    class Program
    {
        static void Main(string[] args)
        {
            int produto, dinheiro, var3; //declarar variaveis em tipo inteiro

            Console.WriteLine("Insira o valor do produto"); //pedir ao utilizador o 1 valor
            produto = int.Parse(Console.ReadLine()); //armazenar o primeiro valor em produto

            Console.WriteLine("Insira o dinheiro"); //pedir ao utilizador o 2 valor
            dinheiro = int.Parse(Console.ReadLine()); //armazenar o primeiro valor em dinheiro

            if (produto == dinheiro) // se o produto for igual ao dinheiro 
            {
                Console.WriteLine("O preço é igual ao valor do produto"); //imprimir o resultado
            } 
            else if (produto < dinheiro) // se o produto for menor do que o dinheiro
            {
                var3 = dinheiro - produto; //subratação do troco
                Console.WriteLine("Vais receber " +var3+ " de troco"); //imprimir o resultado
            }
            else  // se o produto for maior do que o dinheiro
            {
                var3 = produto - dinheiro; //subtração do dinheiro em falta
                Console.WriteLine("Falta-te " +var3+ " dinheiro "); //imprimir o resultado
            }
        }
    }
}
