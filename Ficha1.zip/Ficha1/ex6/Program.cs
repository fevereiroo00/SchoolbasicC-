﻿using System;

namespace ex6
{
    class Program
    {
        static void Main(string[] args)
        {
            int peso, custo, vf; //declarar variaveis em tipo inteiro

            Console.WriteLine("Qual é o peso ?"); //pedir ao utilizador o 1 valor
            peso = int.Parse(Console.ReadLine()); //armazenar o primeiro valor em peso

            Console.WriteLine("Qual é o custo ?"); //pedir ao utilizador o 2 valor
            custo = int.Parse(Console.ReadLine()); //armazenar o primeiro valor em custo

            vf = peso * custo; //produto entre o peso e custo 

            Console.WriteLine("o valor final a ser pago é de " +vf); //imprimir o resultado
        }
    }
}
