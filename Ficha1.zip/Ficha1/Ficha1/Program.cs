﻿using System;

namespace Ficha1
{
    class Program
    {
        static void Main(string[] args)
        {
            string nome; //declarar varivael soma em tipo string
            Console.WriteLine("Escreva o seu nome"); //Pedir ao utilizador o nome
            nome = Console.ReadLine(); //armazenar nome do utilizador em var "nome" 
            Console.WriteLine("Olá " + nome); //imprimir ola com o nome do usuario 
        }
    }
}
